<?php 
include './productData.php';
echo json_encode($products);
?>